# Jujutsu Shenanigans Minecraft

Minecraft Version: Java 26.1.2
Project Version: 0.1.0

## Features

- M1 Combat
- Dash System
- Blocking
- Stun
- Knockback
- Ragdoll
- Uppercut
- Downslam
- Character Abilities
- Awakening
- Destruction
- Multiplayer
- Animations
- Visual Effects
