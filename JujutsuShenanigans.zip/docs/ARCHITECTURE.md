# MOD ARCHITECTURE

Minecraft Java 26.1.2

## Combat
M1, Dash, Block, Stun, Knockback, Ragdoll

## Abilities
Normal abilities, Ultimate abilities, Cooldowns

## Characters
Character selection and character-specific mechanics

## Awakening
Awakening meter and ultimate attacks

## Networking
Server-authoritative combat

## Destruction
Temporary terrain destruction and restoration

## Client
GUI, Animations, Rendering, Camera
