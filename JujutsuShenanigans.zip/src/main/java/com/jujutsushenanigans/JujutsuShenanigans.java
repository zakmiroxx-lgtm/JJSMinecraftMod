package com.jujutsushenanigans;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JujutsuShenanigans implements ModInitializer {

    public static final String MOD_ID = "jujutsu-shenanigans";
    public static final Logger LOGGER =
            LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Jujutsu Shenanigans initialized!");
    }
}
