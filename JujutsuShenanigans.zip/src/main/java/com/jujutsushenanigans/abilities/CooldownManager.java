package com.jujutsushenanigans.abilities;

import java.util.HashMap;
import java.util.Map;

public class CooldownManager {

    private final Map<String, Long> cooldowns = new HashMap<>();

    public boolean isReady(String ability, long now) {
        return now >= cooldowns.getOrDefault(ability, 0L);
    }

    public void activate(String ability, long now, long duration) {
        cooldowns.put(ability, now + duration);
    }

    public long remaining(String ability, long now) {
        return Math.max(0, cooldowns.getOrDefault(ability, 0L) - now);
    }
}
