package com.jujutsushenanigans.awakening;

public class AwakeningSystem {

    private double meter = 0;
    private boolean awakened = false;

    public void addEnergy(double amount) {
        if (!awakened) {
            meter = Math.min(100, meter + Math.max(0, amount));
        }
    }

    public boolean canAwaken() {
        return meter >= 100 && !awakened;
    }

    public boolean activate() {
        if (!canAwaken()) {
            return false;
        }

        awakened = true;
        meter = 0;
        return true;
    }

    public void deactivate() {
        awakened = false;
    }

    public double getMeter() {
        return meter;
    }

    public boolean isAwakened() {
        return awakened;
    }
}
