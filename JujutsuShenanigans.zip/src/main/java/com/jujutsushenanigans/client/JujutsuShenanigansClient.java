package com.jujutsushenanigans.client;

import net.fabricmc.api.ClientModInitializer;

public class JujutsuShenanigansClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        System.out.println("Jujutsu Shenanigans client initialized!");
    }
}
