package com.jujutsushenanigans.combat;

public class DashSystem {

    private long lastDash = Long.MIN_VALUE;
    private static final long COOLDOWN = 2500;

    public boolean canDash(long now) {
        return now - lastDash >= COOLDOWN;
    }

    public boolean dash(long now) {
        if (!canDash(now)) {
            return false;
        }

        lastDash = now;
        return true;
    }
}
