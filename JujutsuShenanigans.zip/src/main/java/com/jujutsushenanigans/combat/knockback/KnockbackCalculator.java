package com.jujutsushenanigans.combat.knockback;

public class KnockbackCalculator {

    public static double[] calculate(
            double directionX,
            double directionZ,
            double strength,
            double upwardForce) {

        double length = Math.sqrt(
            directionX * directionX + directionZ * directionZ
        );

        if (length < 0.0001) {
            return new double[]{0, upwardForce, 0};
        }

        return new double[]{
            directionX / length * strength,
            upwardForce,
            directionZ / length * strength
        };
    }
}
