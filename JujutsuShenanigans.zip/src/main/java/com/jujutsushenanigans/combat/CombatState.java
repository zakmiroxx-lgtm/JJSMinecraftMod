package com.jujutsushenanigans.combat;

public class CombatState {

    private int combo = 0;
    private long lastAttack = 0;
    private long stunnedUntil = 0;
    private boolean blocking = false;

    public int getCombo() {
        return combo;
    }

    public void setCombo(int combo) {
        this.combo = combo;
    }

    public long getLastAttack() {
        return lastAttack;
    }

    public void setLastAttack(long time) {
        this.lastAttack = time;
    }

    public boolean isBlocking() {
        return blocking;
    }

    public void setBlocking(boolean blocking) {
        this.blocking = blocking;
    }

    public boolean isStunned(long now) {
        return now < stunnedUntil;
    }

    public void stun(long now, long duration) {
        stunnedUntil = Math.max(stunnedUntil, now + duration);
    }
}
