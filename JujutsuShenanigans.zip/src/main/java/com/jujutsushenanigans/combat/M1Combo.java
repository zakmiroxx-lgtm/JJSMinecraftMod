package com.jujutsushenanigans.combat;

public class M1Combo {

    private static final long COMBO_RESET_MS = 1200;
    private static final long ATTACK_COOLDOWN_MS = 350;

    public static int attack(CombatState state, long now) {

        if (state.isStunned(now) || state.isBlocking()) {
            return 0;
        }

        long elapsed = now - state.getLastAttack();

        if (state.getLastAttack() != 0
                && elapsed < ATTACK_COOLDOWN_MS) {
            return 0;
        }

        if (elapsed > COMBO_RESET_MS) {
            state.setCombo(0);
        }

        int next = state.getCombo() + 1;

        if (next > 4) {
            next = 1;
        }

        state.setCombo(next);
        state.setLastAttack(now);

        return next;
    }
}
