package com.jujutsushenanigans.combat;

public class BlockSystem {

    public static void startBlocking(CombatState state, long now) {
        if (!state.isStunned(now)) {
            state.setBlocking(true);
        }
    }

    public static void stopBlocking(CombatState state) {
        state.setBlocking(false);
    }

    public static double calculateDamage(
            CombatState target,
            double damage,
            boolean blockBreak) {

        if (target.isBlocking() && !blockBreak) {
            return 0;
        }

        return damage;
    }
}
